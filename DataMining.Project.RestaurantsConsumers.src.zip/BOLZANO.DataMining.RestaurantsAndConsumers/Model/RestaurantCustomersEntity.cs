﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BOLZANO.DataMining.RestaurantsAndConsumers.Model
{
    public abstract class RestaurantCustomersEntity
    {
        public string Name { get; set; }

        public string ID { get; set; }
    }
}
